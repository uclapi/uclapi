from django.apps import AppConfig


class RoombookingsConfig(AppConfig):
    name = 'roombookings'
